﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.AxHost;
using System.Collections;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace практическая_15_по_оа
{
    public partial class Form1 : Form
    {
        ArrayList adress=new ArrayList();
        PochtAdres adres=new PochtAdres();
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("Есть пустые поля");
            }
            else
            {
                int indexToSelect = listBox1.SelectedIndex;
                listBox1.SetSelected(indexToSelect, true);
                string newAdress = $"Улица: {textBox1.Text}, Город: {textBox2.Text}, Область: {textBox3.Text}, Почтовый код: {textBox4.Text}";
                adress[indexToSelect] = newAdress;
                listBox1.Items[indexToSelect] = newAdress;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            button3.Enabled = true;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (File.Exists("pochta.txt"))
            {
                StreamReader sw = File.OpenText("pochta.txt");
                while (!sw.EndOfStream)
                {
                    string st = sw.ReadLine();
                    listBox1.Items.Add(st);
                    adress.Add(st);
                }
                sw.Close();
            }
            else
            {
                MessageBox.Show("Файла нет");
            }
            button3.Enabled = false;
    }   }
}

        